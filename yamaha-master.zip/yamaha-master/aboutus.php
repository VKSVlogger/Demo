 	<!DOCTYPE html>
	<html>
	<head>
	<title>Yamaha</title>
    <!-----------------CSS sheet----------------->
    
	<link href="Resources/css.css" rel="stylesheet" type="text/css">
    
	</head>
	<body>
    
	<!-----------------Wrapper----------------->
    
	<div id="wrapper">  
	<?php include('header.php');?> c 
    
	<!-----------------Main Frame----------------->
    
	<div id="mainframe">
     <div class="sub_framefullpage">
	<h3>About Yamaha</h3>
    
<p>Good things happen when people can move, whether across town or towards their dreams. Opportunities appear, open up, become reality. What started as a way to tap a button to get a ride has led to billions of moments of human connection as people around the world go all kinds of places in all kinds of ways with the help of our technology.</p>
<p>Over the years,  YAMAHA has expanded its Brand into the following business ventures</p>
<p>YAMAHA also has gained its trademark patent license from the National Intellectual Property. This award-winning spare parts dealer in Colombo, Sri Lanka, makes  YAMAHA one of the  best and finest  Online spare parts store in Colombo.
</p>
<h3>Vision</h3>
<p>To be a Sri Lanka's best  Spare parts Dealer </p>

<h3>Mission</h3>
<p>To develop globally competitive and resposible graduates that businessess demand, working in synergy with all our stakeholder and contributing to our society. </p>
<table width="1313" border="0" cellpadding="2" cellspacing="5">
<tr>
<td width="633" align="center" valign="center">
<a target="_blank" href="Resources/designimages/BusinessPerson.jpg"><img src="Resources/designimages/BusinessPerson.jpg"alt="" border=2 height=300 width=300></img></a>
</td>
<td width="657" align="top" valign="Top">
<div style="text-align:center">
<h4><font size="4"/>CHAIRPERSON'S MESSAGE</h4>
</div>
<p> I am proud to say that today, YAMAHA continues to carry the belief system that our late chairman and I built this company 10 years ago. I continue to guide our team to always set higher standards for themselves. We stand by them and give them the strength that years of experience have given us.</p>
</td>
</tr>
</table>
</div>
<div class="clear"></div>

<!-----------------Footer----------------->
	<?php include('Resources/footer.php');?>
    
	</div>
	</div>
	</body>
	</html>