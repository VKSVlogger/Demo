	<div class="footer">
	<div class="col_2">
    <h2>About Yamaha</h2>
    <ul>
	<li><a href="aboutus.php">About us</a></li>
	<li><a href="aboutus.php">Privacy Policy</a></li>
	<li><a href="aboutus.php">Terms of use</a></li>
    </ul>
	</div>
	<div class="col_2">
    <h2>Information</h2>
    <ul>
	<li><a href="aboutus.php">Help & FAQs</a></li>
	<li><a href="aboutus.php">Shipping and delivery</a></li>
    </ul>
	</div>
	<div class="col_2">
    <h2>Contact Us</h2>   
    <ul>
	<li>Hotline:</li>
	<li>Email:</li>
	<li>Services</li>
    </ul>
	</div>
	</div>
