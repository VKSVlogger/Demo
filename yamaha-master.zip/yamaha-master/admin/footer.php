	<div class="footer">
	<div class="col_2" >
    <h2>Yamaha</h2>
    <ul>
	<li>Designed: by 84 </li>
    <li>Version: v1.1</li>
    </ul>
	</div>

	</div>
