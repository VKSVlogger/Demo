	<!DOCTYPE html>
	<html>
	<head>
	<title>Explorer Style</title>
	<link href="Resources/css.css" rel="stylesheet" type="text/css">
	</head>
	<body>
    
	<!-----------------Wrapper----------------->
    
	<div id="wrapper"> 
    
	<!-----------------Header & Navigation Bar----------------->
    
	<?php 
	include('header.php');

	?>
     
	<!-----------------Main Frame----------------->
    
	<div id="mainframe">
	<div class="sub_frame">
    <h3>Order has been successfully Placed</h3>
    <hr>
	</div>    
	<div class="clear"></div>
	<!-----------------Footer----------------->
	<?php include('Resources/footer.php');?>
	</div>
    </div>
	</body>
	</html>